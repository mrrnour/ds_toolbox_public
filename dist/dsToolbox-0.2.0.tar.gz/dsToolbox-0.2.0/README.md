Based on open-source projects such as Pandas, Spark, Sklearn, and the Azure Storage Blob package, this framework offers abstracted functions for performing ETL such as loading and unloading data from different data sources and ML tasks on different platforms including Databricks, Azure ML and local systems:

![image](https://github.com/ExxonMobil/dsToolbox/assets/106990336/89a74edc-2e87-42a2-a93e-98e4d51d577b)

![image](https://github.com/ExxonMobil/dsToolbox/assets/106990336/52b223bb-8397-44b3-b4a7-8bc6380236c8)

![image](https://github.com/ExxonMobil/dsToolbox/assets/106990336/fa1bb7f3-024b-4fc2-9b78-2ee63b53f03a)

For more information please see:
https://spsharing1.exxonmobil.com/sites/UDA/_layouts/15/start.aspx#/Opportunities%20%20Pilots/Forms/AllItems.aspx?RootFolder=%2Fsites%2FUDA%2FOpportunities%20%20Pilots%2Fds%5Ftoolbox&FolderCTID=0x0120004FB3C233F1C9B2458B35C07F989CE129&View=%7B809973D0%2D303E%2D4D5C%2D985A%2D8E62B71658E8%7D&InitialTabId=Ribbon%2ERead&VisibilityContext=WSSTabPersistence

