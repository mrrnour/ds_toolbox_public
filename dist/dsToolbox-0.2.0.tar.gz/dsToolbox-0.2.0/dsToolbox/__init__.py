
# from dsToolbox import common_funcs
# from dsToolbox import io_funcs
# from dsToolbox import ml_funcs
# from dsToolbox import spark_funcs
# from dsToolbox import config
# from dsToolbox import sql_template
from dsToolbox import default_values
from importlib import resources as res
import yaml

with res.open_binary('dsToolbox', 'config.yml') as fp:
    config_dict = yaml.load(fp, Loader=yaml.Loader)
    
with res.open_binary('dsToolbox', 'sql_template.yml') as fp:
    sql_template_dict = yaml.load(fp, Loader=yaml.Loader)

print('dsToolbox was successfully imported')
